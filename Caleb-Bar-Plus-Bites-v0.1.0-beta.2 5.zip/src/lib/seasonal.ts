import type { MenuItem } from './types';
export const seasonalDrafts: MenuItem[] = [
  ['apple', 'Harvest Apple Fizz', 425, '🍎'],
  ['maple', 'Maple Harvest Sparkler', 450, '🍁'],
  ['cranberry', 'Cranberry Celebration Mocktail', 425, '🍒'],
  ['grilled', 'Thanksgiving Grilled Cheese', 450, '🧀'],
  ['popcorn', 'Harvest Popcorn', 300, '🍿'],
  ['opening', 'Grand Opening Combo', 675, '🎉'],
  ['surprise', 'Thanksgiving Surprise Mocktail', 375, '🦃'],
  ['autumn', 'Autumn Celebration Combo', 750, '🍂'],
].map(([id, name, price, emoji]) => ({
  id: 'thanksgiving-' + id,
  name: String(name),
  price: Number(price),
  emoji: String(emoji),
  category: 'Specials',
  special: true,
  seasonal: true,
  visibility: 'order',
  available: false,
  description:
    'A Thanksgiving grand opening draft. Management must confirm ingredients, availability, and preparation details before enabling.',
}));

export const defaultSeasonal = {
  thanksgiving: false,
  decorations: false,
  animations: false,
  turkey: true,
  pumpkins: true,
  leaves: true,
  fallingLeaves: true,
  confetti: true,
  seasonalAnnouncements: true,
  farm: true,
  other: true,
  lightweight: false,
};
export function seasonalSettings(value?: Partial<typeof defaultSeasonal>) {
  return { ...defaultSeasonal, ...value };
}
export const decorationControls = [
  ['thanksgiving', 'Thanksgiving mode'],
  ['decorations', 'Grand opening decorations'],
  ['animations', 'Seasonal animations'],
  ['turkey', 'Thanksgiving turkey decorations'],
  ['pumpkins', 'Pumpkins'],
  ['leaves', 'Autumn leaves'],
  ['fallingLeaves', 'Falling leaf animations'],
  ['confetti', 'Grand opening confetti'],
  ['seasonalAnnouncements', 'Seasonal announcements'],
  ['farm', 'Farm scenery'],
  ['other', 'Other decorative elements'],
  ['lightweight', 'Lightweight graphics mode'],
] as const;
