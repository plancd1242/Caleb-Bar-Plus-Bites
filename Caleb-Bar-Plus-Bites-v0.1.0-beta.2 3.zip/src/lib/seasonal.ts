import type { MenuItem } from './types';
export const seasonalDrafts: MenuItem[] = [
  ['apple', 'Harvest Apple Fizz', 425, '🍎'],
  ['maple', 'Maple Harvest Sparkler', 450, '🍁'],
  ['cranberry', 'Cranberry Celebration Mocktail', 425, '🍒'],
  ['grilled', 'Thanksgiving Grilled Cheese', 450, '🧀'],
  ['popcorn', 'Harvest Popcorn', 300, '🍿'],
  ['opening', 'Grand Opening Combo', 675, '🎉'],
  ['surprise', 'Thanksgiving Surprise Mocktail', 375, '🦃'],
  ['autumn', 'Autumn Celebration Combo', 750, '🍂'],
].map(([id, name, price, emoji]) => ({
  id: 'thanksgiving-' + id,
  name: String(name),
  price: Number(price),
  emoji: String(emoji),
  category: 'Specials',
  special: true,
  seasonal: true,
  visibility: 'order',
  available: false,
  description:
    'A Thanksgiving grand opening draft. Management must confirm ingredients, availability, and preparation details before enabling.',
}));

export const defaultSeasonal = { thanksgiving: false, decorations: false, animations: false };
